﻿using System.Windows;

namespace KeepYourTime.ViewWindows
{
    /// <summary>
    /// Interaction logic for InactivityWindow.xaml
    /// </summary>
    public partial class InactivityWindow : Window
    {
        public InactivityWindow()
        {
            InitializeComponent();
        }
    }
}
