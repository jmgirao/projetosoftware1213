﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeepYourTime.ViewControls.TaskDetailsControls
{
    public enum EditTaskContex
    {
        MainWindow=0,
        DetailWindow
    }
}
