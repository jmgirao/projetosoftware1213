﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeepYourTime
{
    /// <summary>
    /// Enumeration to have the MethodStatus
    /// </summary>
    /// <remarks>CREATED BY Rui Ganhoto</remarks>
    public enum MethodStatus
    {
        Success=0,
        Cancel,
        Exception
    }
}
