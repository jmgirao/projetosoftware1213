A dashboard, logs e outros documentos usados, podem ser consultados em ficheiros fornecidos ou no website:
https://sites.google.com/site/misps1213/

Devido a algumas incompatibilidades entre o Google Docs e o Microsoft Excel, recomenda-se que a consulta destes documentos seja feita pelo website.

Para execu��o da aplica��o ser� necessario garantir que est�o instaladas as seguintes bibliotecas:
-Microsoft .NET Framework 4.5 (http://www.microsoft.com/en-us/download/details.aspx?id=30653)
-Microsoft SQL Server Compact 4.0 (http://www.microsoft.com/en-us/download/details.aspx?id=17876)

KeepYourTime
+---Docs
�   +---Logs                    - Logs pessoais semanais
�   +---Measures                - Documentos de medidas
�   +---Meetings                - Meetings semanais
�   �   +---Minutes		- Atas Baselined
�   +---Processes               - Conjunto de processos
�   �   +---Diagrams            - Diagramas de interliga��o entre processos
�   +---Project documentation   - SDP, Vision & Scope, requisitos e planos relacionados com o projeto
�   �   +---Auxiliary Documents - Documentos auxiliares para a constru��o de outros documentos do projeto
�   �   +---Mockups             - Mockups usadas no desenvolvimento da aplica��o
�   �   +---SRS                 - SRS do projeto
�   �   �   +---Inspection      - Resultados da inspe��o ao SRS pela outra equipa
�   �   +---Tests               - Documentos do plano de testes
�   +---Project Management      - Documentos de gest�o do estado do projeto
�   +---Templates               - Templates usados para os diferentes documentos
�   +---Test Results            - Conjunto de documentos referentes � execu��o dos testes
�   �   +---Bugs                - Bugs n�o resolvidos
�   �   +---RESOLVED            - Bugs resolvidos
�   �   +---Usability result    - Resultado dos testes de usabilidade
�   �   +---VALIDATED           - Bugs corrigidos a aguardar valida��o
�   +---Weekly Report           - Weekly reports
+---Presentations               - Ficheiros para a apresenta��o
+---Project
    +---KeepYourTime            - Pasta raiz do codigo fonte da aplica��o
    +---KeepYourTime - Execs    - Pasta com os executaveis da aplica��o
 
 
----KeepYourTime
    +---Docs
    �   +---Logs
    �   +---Measures
    �   +---Meetings
    �   �   +---Minutes
    �   +---Processes
    �   �   +---Diagrams
    �   +---Project documentation
    �   �   +---Auxiliary Documents
    �   �   +---Mockups
    �   �   +---SRS
    �   �   �   +---Inspection
    �   �   +---Tests
    �   +---Project Management
    �   +---Templates
    �   +---Test Results
    �   �   +---Bugs
    �   �   +---RESOLVED
    �   �   +---Usability result
    �   �   +---VALIDATED
    �   +---Weekly Report
    +---Presentations
    +---Project
        +---KeepYourTime
        �   +---KeepYourTime
        �   �   +---Assets
        �   �   �   +---icons
        �   �   +---DataBase
        �   �   �   +---Adapters
        �   �   �   +---Connectors
        �   �   +---Hooks
        �   �   +---Languages
        �   �   +---lib
        �   �   �   +---ExtendedWPFToolkit_Binaries
        �   �   +---Properties
        �   �   +---Utils
        �   �   +---ViewControls
        �   �   �   +---ConfigurationControls
        �   �   �   +---InactivityControls
        �   �   �   +---MainWindowControls
        �   �   �   +---TaskDetailsControls
        �   �   +---ViewWindows
        �   +---KeepYourTimeTestProject
        �       +---DatabaseModuleTests
        �       +---EditTaskTests
        �       +---Properties
        +---KeepYourTime - Execs