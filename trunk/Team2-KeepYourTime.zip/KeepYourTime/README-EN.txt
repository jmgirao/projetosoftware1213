The dashboard, logs and other used documents, can be consulted in the files provided or via website:
https://sites.google.com/site/misps1213/

Due to some incompatibilities between Google Docs and Microsoft Excel, it is recommended that the consult of these documents is performed through website.

To run the application will be necessary to ensure that they are installed the following libraries:
-Microsoft .NET Framework 4.5 (http://www.microsoft.com/en-us/download/details.aspx?id=30653)
-Microsoft SQL Server Compact 4.0 (http://www.microsoft.com/en-us/download/details.aspx?id=17876)

KeepYourTime
+---Docs
�   +---Logs                    - Weekly personal logs
�   +---Measures                - Measures documents
�   +---Meetings                - Weekly meetings
�   +---Processes               - Collection of processes
�   �   +---Diagrams            - Interconnection diagrams between processes
�   +---Project documentation   - SDP, Vision & Scope, requirements and plans related to the project
�   �   +---Auxiliary Documents - Auxiliary documents for the construction of other project documents
�   �   +---Mockups             - Mockups used in application development
�   �   +---SRS                 - Project SRS
�   �   �   +---Inspection      - Inspection results to the SRS by the other team
�   �   +---Tests               - Documents of the test plan
�   +---Project Management      - Management documents of project status
�   +---Templates               - Templates used for different documents
�   +---Test Results            - Set of documents relating to the execution of tests
�   �   +---Bugs                - Unresolved bugs
�   �   +---RESOLVED            - Resolved bugs
�   �   +---Usability result    - Results of usability testing
�   �   +---VALIDATED           - Bugs fixed awaiting validation
�   +---Weekly Report           - Weekly reports
+---Presentations               - Files for presentation
+---Project
    +---KeepYourTime            - Root folder of the source code of the application
    +---KeepYourTime - Execs    - Folder with the executables of the application
 
 